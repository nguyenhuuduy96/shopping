
<?php $__env->startSection('title','product'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg0 m-t-100 p-b-140">
	<div class="container">
		
		<div class="flex-w flex-sb-m p-b-5 ">
			<div class="flex-w flex-l-m filter-tope-group m-tb-10">
				<a href="/" class="stext-106 cl6 hov-cl1 bor3 trans-04 m-r-32 m-tb-5" data-filter="*">
					Trang chủ
					<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
				</a>

				<a href="<?php echo e(route('home.product')); ?>" class="stext-106 cl6 hov-cl1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".women">
					Danh mục
					<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
				</a>

				<a class="stext-106 cl6 hov-cl1 bor3 trans-04 m-r-32 m-tb-5 " data-filter=".men">
					<?php if(isset($cate)): ?>
					<input type="hidden" name="slug_cate" value="<?php echo e($cate->slug); ?>" id="slug_cate">
					<?php echo e($cate->name); ?>

					<?php else: ?>
					<input type="hidden" name="slug_cate" value="" id="slug_cate">
					<?php endif; ?>
				</a>

				
			</div>

			<div class="flex-w flex-c-m m-tb-10">
				
				<div >
					<select class="stext-106 cl6 size-104 bor4 m-r-8 m-tb-4" id="count-show-product">
						<option value="12" >Show 12</option>
						<option value="16">Show 16</option>
						<option value="32" >Show 32</option>
						<option value="64" >Show 64</option>
						<option value="128">Show 128</option>
						
					</select>
				</div>
				<div class="flex-c-m stext-106 cl6 size-105 bor4 pointer hov-btn3 trans-04 m-tb-4 js-show-search">
					<i class="icon-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-search"></i>
					<i class="icon-close-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-close dis-none"></i>
					Search
				</div>
			</div>

			<!-- Search product -->
			<div class="dis-none panel-search w-full p-t-10 p-b-15">
				
				<div class="bor8 dis-flex p-l-15">
					<button class="size-113 flex-c-m fs-16 cl2 hov-cl1 trans-04">
						<i class="zmdi zmdi-search"></i>
					</button>

				<input class="mtext-107 cl2 size-114 plh2 p-r-15" type="text" id="search-product" name="search-product" value="<?php echo e(isset($_GET['SearchProduct'])?$_GET['SearchProduct']:''); ?>" placeholder="Search">
				</div>	
			</div>

			<!-- Filter -->

		</div>

		<div class="row isotope-grid">
			

			
		</div>

		<!-- Load more -->
		<div class="flex-c-m flex-w w-full p-t-20 total-page">
			
		</div>
	</div>
</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('home/js/product.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/home/product.blade.php ENDPATH**/ ?>