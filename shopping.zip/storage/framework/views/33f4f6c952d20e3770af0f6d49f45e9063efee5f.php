<link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free-5.13.1/css/all.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/fonts/linearicons-v1.0.0/icon-font.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/animsition/css/animsition.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/daterangepicker/daterangepicker.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/slick/slick.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/MagnificPopup/magnific-popup.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/main.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php /**PATH E:\hoc laravel\Product\resources\views/layouts/home/layouts/css.blade.php ENDPATH**/ ?>