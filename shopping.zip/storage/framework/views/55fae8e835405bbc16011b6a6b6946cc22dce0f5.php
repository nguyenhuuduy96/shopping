
<?php $__env->startSection('title', 'slide show'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>Show
                                        <select name="example1_length" class="form-control-sm" id="show">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries</label>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <form method="get">
                                    <div id="dataTables_length" class="dataTables_filter">
                                        <label class="form-control-sm">Search:
                                            <input type="search" id="searh_product" class="form-control-sm" name="search"
                                                placeholder="tên sản phẩm"></label>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div id="sign-in-button" style="display: none;"></div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">

                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>image</th>
                                    <th>Description</th>
                                    <th>Active</th>
                                    <th><a data-toggle="modal" data-target="#ModalSlide" class="restForm"><i
                                                class="fa fa-plus-square text-success " ></i> New Slide Show</a></th>

                                </tr>
                            </thead>
                            <tbody id="search_Show">
                                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($slide->id); ?></td>
                                        <td><?php echo e($slide->title); ?></td>
                                        <td><img src="<?php echo e($slide->image); ?>" alt="" width="50px"></td>
                                        <td><?php echo e($slide->desciption); ?></td>
                                        <td>
                                            <?php if($slide->active == 0): ?>
                                                <a class="btn btn-danger text-white"
                                                    onclick="active(this,<?php echo e($slide->id); ?>)">Disable</a>
                                            <?php else: ?>
                                                <a class="btn btn-success text-white"
                                                    onclick="active(this,<?php echo e($slide->id); ?>)">Enable</a>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                        <a class="btn btn-app" class="btn btn-success" data-toggle="modal"
                                            data-target="#ModalProduct" id="updateProduct"
                                            onclick="Getupdate(this,'<?php echo e($slide->id); ?>')"><i
                                                class="fa fa-edit text-primary"></i>Edit</a>
                                        <a class="btn btn-app" class="btn btn-success" id="deleteRow"
                                            onclick="deleteSlide(this,'<?php echo e($slide->id); ?>')"><i
                                                class="fas fa-trash-alt text-danger"></i>delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-2 " id="paga-link">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Modal form-->
    <?php echo $__env->make('admin.slideshow.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin/js/admin/slideshow.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/slideshow/list.blade.php ENDPATH**/ ?>