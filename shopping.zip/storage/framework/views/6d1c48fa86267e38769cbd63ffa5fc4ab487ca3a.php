
<?php $__env->startSection('title', 'user'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>Show
                                        <select name="example1_length" class="form-control-sm" id="show">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries</label>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <form method="get">
                                    <div id="dataTables_length" class="dataTables_filter">
                                        <label class="form-control-sm">Search:
                                            <input type="search" id="searh_product" class="form-control-sm" name="search"
                                                placeholder="tên sản phẩm"></label>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div id="sign-in-button" style="display: none;"></div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">

                            <thead>
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Tên</th>
                                    <th>avatar</th>
                                    <th>Số điện thoại</th>
                                    <th>chọn quyền</th>
                                    <th>quyền hiện tại</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody id="search_Show">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td class="text-center"><img
                                                src="<?php echo e($user->avatar !== null ? $user->avatar : '../../../img/avatar.png'); ?>"
                                                width="50px" alt=""></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><select class="form-control" name="is_active" id="is_active">
                                                <option value="">-- chọn --</option>
                                                <?php $__currentLoopData = $decentralizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td><p class="btn btn-primary"><?php echo e(isset($user->decentralization->name) ? $user->decentralization->name : 'null'); ?></p>
                                        </td>
                                        <td><a class="btn btn-primary text-white" onclick="save(this,<?php echo e($user->id); ?>)">Lưu</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-2 " id="paga-link">

                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin/js/admin/user.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/user/list.blade.php ENDPATH**/ ?>