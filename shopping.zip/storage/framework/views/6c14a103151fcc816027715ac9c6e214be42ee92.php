
<?php $__env->startSection('title','product detail'); ?>
<?php $__env->startSection('content'); ?>
	
		

	
	<section class="col-sm-12 bg0 p-t-90 p-b-60 ">
        <p class="col-sm-6 rounded mx-auto d-block">Số lượng sản phẩm hết hàng hoặc số lượng sản phẩm vượt quá số lượng trong kho!</p>
    <a class="btn btn-primary text-center rounded mx-auto d-block col-sm-2" href="<?php echo e(route('cart.show')); ?>">chở về giỏ hàng</a>
	</section>


	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/home/errorQuantity.blade.php ENDPATH**/ ?>