
<?php $__env->startSection('title', 'profile'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">

            <div class="card col-sm-12">
                <div class="card-body ">
                    
                    <form class="row" action="javascript:void(0)" id="formsubmit">
                        <?php echo csrf_field(); ?>
                        <p class="title text-center text-success col-sm-12"></p>
                        <div class="col-sm-7 row">
                            <div class="form-group col-sm-5">
                                <label for="user_name">Họ tên:</label>
                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo e(Auth::user()->id); ?>">
                                
                            </div>
                            <div class="form-group col-sm-7">
                                
                                <input type="type" class="form-control" id="user_name" placeholder="name" name="name" value="<?php echo e(Auth::user()->name); ?>">
                                <span class="error_name" style="color: red"></span>
                            </div>
                            <div class="form-group col-sm-5">
                                <label for="email">Email:</label>
                                
                            </div>
                            <div class="form-group col-sm-7">
                                
                                <input type="type" class="form-control" id="email" placeholder="email"
                            name="email" value="<?php echo e(Auth::user()->email); ?>" 
                            <?php if(Auth::user()->email != null || Auth::user()->email != '' ): ?>
                            disabled
                            <?php endif; ?>
                            >
                                <span class="error_email" style="color: red"></span>
                            </div>
                            <div class="form-group col-sm-5">
                                <label for="image">Avatar:</label>
                            <input type="hidden" name="anh" id="anh" class="anh" value="<?php echo e(Auth::user()->avatar); ?>">
                                
                            </div>
                            <div class="form-group col-sm-7">
                                
                                <input type="file" class="form-control" id="image" placeholder="image" name="images">
                                <span class="error_image" style="color: red"></span>
                            </div>
                            <div class="form-group col-sm-5">
                                <label for="phone">số điện thoại:</label>
                                
    
                            </div>
                            <div class="form-group col-sm-7">
                                
                                <input type="text" class="form-control" id="phone" placeholder="phone" name="url" value="<?php echo e(Auth::user()->phone); ?>"
                                <?php if(Auth::user()->phone !== ''): ?>
                                disabled  
                                <?php endif; ?>
                                >
    
                            </div>
                            
                        </div>
                        
                        <div class ="col-sm-5 mx-auto  image">
                            
                                
                                <label for="image" class="text-center rounded mx-auto d-block">
                                    <img  src="<?php echo e(Auth::user()->avatar !== null ? Auth::user()->avatar : '../../../img/avatar.png'); ?>" class="rounded-circle rounded mx-auto d-block showimage" width="100px" height="100px">
                                    Avatar</label>
                            
                        </div>
                        <input type="submit" value="Save" class="btn btn-primary">
        
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/js/admin/profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>