
<?php $__env->startSection('title','checkout'); ?>
<?php $__env->startSection('content'); ?>
<section class="content p-t-75">
  <div class="container-fluid">
    <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
      <a href="/" class="stext-109 cl8 hov-cl1 trans-04">
        Home
        <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
      </a>

      <a href="<?php echo e(route('check.bill.home')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
        chi tiết đơn hàng
      </a>


    </div>
    <div class="row">
      <div class="col-12">
        <?php if($bill->status_id<2): ?>
        <div class="callout callout-info">

          <div class="alert alert-primary mt-4">
            Đặt hàng thành công.
          </div>

        </div>
        <?php endif; ?>


        <!-- Main content -->
        <div class="invoice p-3 mb-3">
          <!-- title row -->
          <div class="row">
            <div class="col-12">

            </div>
            <!-- /.col -->
          </div>
          <!-- info row -->
          <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
              Địa chỉ thanh toán
              <address>
                <strong><?php echo e(isset($bill->address->name)?$bill->address->name:'???'); ?></strong><br>
                <?php echo e(isset($bill->address->city)?$bill->address->city:'???'); ?>, <?php echo e(isset($bill->address->district)?$bill->address->district:'???'); ?>, 
                <?php echo e(isset($bill->address->address)?$bill->address->address:'???'); ?><br>
                Phone: <?php echo e(isset($bill->address->phone)?$bill->address->phone:'???'); ?><br>

              </address>
            </div>
            <!-- /.col -->
            <div cla s="col-sm-4 invoice-col">
              Địa chỉ gửi hàng
              <address>
                <strong><?php echo e(isset($bill->address->name)?$bill->address->name:'???'); ?></strong><br>
                <?php echo e(isset($bill->address->city)?$bill->address->city:'???'); ?>, <?php echo e(isset($bill->address->district)?$bill->address->district:'???'); ?>, 
                <?php echo e(isset($bill->address->address)?$bill->address->address:'???'); ?><br>
                Phone: <?php echo e(isset($bill->address->phone)?$bill->address->phone:'???'); ?><br>

              </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">

              <b>bill ID:</b> <?php echo e($bill->bill_code); ?><br>
              <b>Thời gian đặt:</b> <?php echo e($bill->created_at); ?><br>

            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->

          <!-- Table row -->
          <div class="row">
            <div class="col-12 table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>

                    <th>Tên sản phẩm</th>
                    <th>màu</th>
                    <th>size</th>
                    <th>số lượng</th>

                    <th>Giá tiền</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $bill->bill_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>

                    <td><a href="<?php echo e(route('detail.product', $detail->product->slug)); ?>"><?php echo e($detail->product->name); ?></a></td>
                    <td><?php echo e($detail->color); ?></td>
                    <td><?php echo e($detail->size); ?></td>
                    <td><?php echo e($detail->quantity); ?></td>

                    <td><?php echo e($detail->total); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->

          <div class="row">
            <!-- accepted payments column -->
            <div class="col-6">

            </div>
            <!-- /.col -->
            <div class="col-6">


              <div class="table-responsive">
                <table class="table">

                  <th>Giá tiền:</th>
                  <td><?php echo e(number_format($bill->total ,0 ,'.' ,'.')); ?></td>
                </tr>
              </table>
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- this row will not appear when printing -->
        <div class="row no-print">

        </div>
      </div>
      <!-- /.invoice -->
    </div><!-- /.col -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/home/checkoutsuccess.blade.php ENDPATH**/ ?>