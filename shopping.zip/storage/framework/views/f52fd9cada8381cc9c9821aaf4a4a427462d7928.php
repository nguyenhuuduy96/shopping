
<?php $__env->startSection('title', 'list bill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>Show
                                        <select name="example1_length" class="form-control-sm" id="show">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries</label>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <form method="get">
                                    <div id="dataTables_length" class="dataTables_filter">
                                        <label class="form-control-sm">Search:
                                            <input type="search" id="searh_phone" class="form-control-sm" name="search"
                                                placeholder="phone number">
                                        </label>
                                        <span class="text-danger error_phone"></span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="tablebill" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Bill code</th>
                                    <th>time create</th>
                                    <th>total</th>
                                    <th>status</th>
                                    <th>

                                    </th>

                                </tr>
                            </thead>
                            <tbody id="search_Show">
                                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><a href="<?php echo e(route('admin.bill.detail', $bill->bill_code)); ?>">
                                                <?php echo e($bill->bill_code); ?></a></th>
                                        <th><?php echo e($bill->created_at); ?></th>
                                        <th><?php echo e(number_format($bill->total, 0, '.', '.')); ?> đ</th>
                                        <th><?php echo e(isset($bill->status) ? $bill->status->name : ''); ?></th>
                                        <th>
                                            <a class="btn btn-primary"
                                                onclick="confirmBill(this,<?php echo e($bill->id); ?>,<?php echo e($bill->status_id); ?>)">
                                                Xác nhận đơn</a>
                                            <a class="btn btn-danger"
                                                onclick="cancelBill(this,<?php echo e($bill->id); ?>,<?php echo e($bill->status_id); ?>)">Hủy
                                                đơn</a>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center mt-2 " id="paga-link"></div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('admin/js/admin/bill.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/bills/list.blade.php ENDPATH**/ ?>