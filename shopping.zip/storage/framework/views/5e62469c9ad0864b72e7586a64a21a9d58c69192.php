    
<?php $__env->startSection('title','category-product'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="dataTables_length" id="example1_length">
                <label>Show 
                  <select name="example1_length" class="form-control-sm" >
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select> entries</label>
                </div>
              </div>
              <div class="col-sm-12 col-md-6">
                <form  method="get">
                  <div id="dataTables_length" class="dataTables_filter">
                    <label class="form-control-sm">Search:
                      <input type="search" id="searh_product" class="form-control-sm" name="search" placeholder="">
                    </label>
                  </div>
                </form>
              </div> 
            </div>
          </div>
          <div class="card-body">
            <table id="tableCategoryProduct" class="table table-bordered table-striped">

              
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>category parent</th>
                  <th>
                    <a data-toggle="modal" data-target="#modalcategory" onclick="newform()" ><i class="fa fa-plus-square text-primary"></i> New Category
                    </a>
                  </th>

                </tr>
              </thead>
              <tbody id="search_Show">
                <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th><?php echo e($cate->id); ?></th>
                  <th><?php echo e($cate->name); ?></th>
                  <th><?php echo e(isset($cate->cate)?$cate->cate->name:''); ?></th>
                  <th>
                    <a class="btn btn-primary" onclick="update(this,<?php echo e($cate->id); ?>)" data-toggle="modal" data-target="#modalcategory">
                    update</a>
                    <a class="btn btn-danger" onclick="DeleteCategory(this,<?php echo e($cate->id); ?>)">delete</a>
                  </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
            <div class="d-flex justify-content-center mt-2 " id="paga-link"></div>
          </div>
          <!-- /.card-body -->

        </div>
      </div>
    </div>
  </div>
  
  <?php echo $__env->make('admin.category_product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('admin/js/admin/cateProduct.js')); ?>"></script>
  <script type="text/javascript">
    window.addEventListener('load', function(e) {
     $.ajax({
      url:'../api/category-product/list',
      type:'get',
      success:function(data){
        console.log(data.length)
        let countCate= data.length;
        let TotlaPage = Math.ceil(countCate/2);
        let showPagaLink =`<nav>
        <ul class="pagination">
          <li class="page-item disabled" aria-disabled="true" aria-label="« Previous">
            <span class="page-link" aria-hidden="true">‹</span>
          </li>`;
        for (var i = 1; i <= TotlaPage; i++) {
          showPagaLink+=`<li class="page-item" aria-current="page"><span class="page-link">`+i+`</span></li> `;
        }
        showPagaLink+=` <li class="page-item">
                  <a class="page-link" rel="next" aria-label="Next »">›</a>
                  </li>
                  </ul>
        </nav>`;
        document.getElementById('paga-link').innerHTML=showPagaLink;
        console.log(showPagaLink)
        // console.log(data)
        // let list = '<option value="">- chon -</option>';
        // for(const x of data){
        //   list+='<option value="'+x.id+'" > '+x.name+'</option>'
        //   // console.log(x.id)
        //   // return false;
        // }
        // document.getElementById('allsize').innerHTML=list;
      }
    })
   });

 </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hoc laravel\Product\resources\views/admin/category_product/list.blade.php ENDPATH**/ ?>