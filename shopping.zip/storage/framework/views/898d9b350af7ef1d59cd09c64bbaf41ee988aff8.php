
<?php $__env->startSection('title', 'product'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>Show
                                        <select name="example1_length" class="form-control-sm" id="show">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries</label>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <form method="get">
                                    <div id="dataTables_length" class="dataTables_filter">
                                        <label class="form-control-sm">Search:
                                            <input type="search" id="searh_product" class="form-control-sm" name="search"
                                                placeholder="tên sản phẩm"></label>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div id="sign-in-button" style="display: none;"></div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">

                            
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name Product</th>
                                    <th>Source</th>
                                    <th>Time_expired</th>
                                    <th><a data-toggle="modal" data-target="#ModalProduct" onclick="productFormRest()"><i
                                                class="fa fa-plus-square text-success"></i> New Product</a></th>
                                    <th>
                                        <a data-toggle="modal" data-target="#modalTableSize"> <i class="fas fa-table"></i>
                                            Table Size</a>
                                        <a data-toggle="modal" data-target="#modalTableColor"> <i class="fas fa-table"></i>
                                            Table Color</a>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="search_Show">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->source); ?></td>
                                        <td><?php echo e($product->time_expired); ?></td>
                                        <td><a class="btn btn-app" class="btn btn-success" data-toggle="modal"
                                                data-target="#ModalProduct" id="updateProduct"
                                                onclick="onclickupdate(this,'<?php echo e($product->id); ?>')"><i
                                                    class="fa fa-edit text-primary"></i>Edit</a></td>
                                        <td><a class="btn btn-app" class="btn btn-success" id="deleteRow"
                                                onclick="tabledeleteProduct(this,'<?php echo e($product->id); ?>')"><i
                                                    class="fas fa-trash-alt text-danger"></i>delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tfoot>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-2 " id="paga-link">
						
					</div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>
    <!--Modal form products-->
    <?php echo $__env->make('admin.product.form-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Modal Talbe size-->
    <?php echo $__env->make('admin.product.form-size', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Modal Talbe size-->
    <?php echo $__env->make('admin.product.form-color', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin/js/admin/product.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/product/list.blade.php ENDPATH**/ ?>