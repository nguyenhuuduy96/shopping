    
<?php $__env->startSection('title','category Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="dataTables_length" id="example1_length">
                <label>Show 
                  <select name="example1_length" class="form-control-sm" >
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select> entries</label>
                </div>
              </div>
              <div class="col-sm-12 col-md-6">
                <form  method="get">
                  <div id="dataTables_length" class="dataTables_filter">
                    <label class="form-control-sm">Search:
                      <input type="search" id="searh_product" class="form-control-sm" name="search" placeholder="">
                    </label>
                  </div>
                </form>
              </div> 
            </div>
          </div>
          <div class="card-body">
            <table id="tableCategoryProduct" class="table table-bordered table-striped">

              
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>category parent</th>
                  <th>
                    <a data-toggle="modal" data-target="#modalcategory" onclick="newform()" ><i class="fa fa-plus-square text-primary"></i> New Category
                    </a>
                  </th>

                </tr>
              </thead>
              <tbody id="search_Show">
                <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th><?php echo e($cate->id); ?></th>
                  <th><?php echo e($cate->name); ?></th>
                  <th><?php echo e(isset($cate->cate)?$cate->cate->name:''); ?></th>
                  <th>
                    <a class="btn btn-primary" onclick="update(this,<?php echo e($cate->id); ?>)" data-toggle="modal" data-target="#modalcategory">
                    update</a>
                    <a class="btn btn-danger" onclick="DeleteCategory(this,<?php echo e($cate->id); ?>)">delete</a>
                  </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
            <div class="d-flex justify-content-center mt-2 " id="paga-link"></div>
          </div>
          <!-- /.card-body -->

        </div>
      </div>
    </div>
  </div>
  
  <?php echo $__env->make('admin.blogCategory.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/js/admin/cateBlog.js')); ?>"></script>
  <script type="text/javascript">
    
    

 </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_admins.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shopping\resources\views/admin/blogCategory/list.blade.php ENDPATH**/ ?>