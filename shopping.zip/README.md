# Shopping

# Quản lý sản phẩm

1. Thêm, sửa, xóa sản phẩm

2. Sản phẩm phân hóa theo size, một sản phẩm thì có nhiều size, mỗi size cũng có nhiều giá tiền khác nhau

3. Một sản phẩm thì có nhiều ảnh và được đánh số thứ tự sắp xếp các ảnh được hiễn thị

4. Sử dụng ajax thêm sửa xóa sản phẩm để không load lại trang

5. Command run project : php artisan serve

6. Câp nhập thư viện command : composer install

7. Cập nhật database command : php artisan migrate

8. Login dùng Firebase check verify number phone javascript

9. Thêm giỏ hàng bằng thư viện darryldecode/cart
