<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Decentralization extends Model
{
    protected $table = 'decentralizations';
    protected $fillable = ['name'];
}
